let selectedStyle = "modern";
let currentData = null;

document.querySelectorAll(".style").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".style").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedStyle = btn.dataset.style;
  });
});

document.getElementById("builderForm").addEventListener("submit", e => {
  e.preventDefault();
  currentData = {
    name: val("name"),
    type: val("type"),
    location: val("location"),
    description: val("description"),
    services: val("services"),
    hours: val("hours"),
    contact: val("contact"),
    style: selectedStyle
  };
  renderSite();
  document.getElementById("result").classList.remove("hidden");
  document.getElementById("result").scrollIntoView({behavior:"smooth"});
});

document.getElementById("reset").addEventListener("click", () => {
  document.getElementById("result").classList.add("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
});

document.getElementById("editBtn").addEventListener("click", () => {
  const prompt = val("editPrompt").toLowerCase();
  if (!prompt.trim()) return;
  if (prompt.includes("luxur")) currentData.style = "luxury";
  else if (prompt.includes("minimal") || prompt.includes("simple")) currentData.style = "minimal";
  else if (prompt.includes("bold")) currentData.style = "bold";
  else if (prompt.includes("modern")) currentData.style = "modern";

  if (prompt.includes("shorter")) currentData.description = currentData.description.split(".")[0] + ".";
  if (prompt.includes("uppercase")) currentData.name = currentData.name.toUpperCase();

  renderSite();
  document.getElementById("editStatus").textContent = "Updated your preview.";
});

function val(id){return document.getElementById(id).value.trim()}

function renderSite(){
  const d = currentData;
  const services = d.services.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
  const serviceHTML = services.length
    ? services.map(s => {
        const parts=s.split(/\s+[—-]\s+|\s{2,}/);
        return `<div class="service"><b>${escapeHTML(parts[0])}</b><span class="muted">${escapeHTML(parts.slice(1).join(" — "))}</span></div>`
      }).join("")
    : `<div class="service"><b>Our services</b><span class="muted">Add your services in the builder.</span></div>`;

  const contact = d.contact || "Contact us to get started";
  document.getElementById("resultTitle").textContent = `${d.name} — preview`;
  document.getElementById("sitePreview").innerHTML = `
    <div class="generated ${d.style}" style="--hero-bg:${d.style==="luxury"?"#171717":d.style==="bold"?"#111":d.style==="minimal"?"#fafafa":"#f0f3ff"}">
      <div class="nav">
        <strong>${escapeHTML(d.name)}</strong>
        <span>${escapeHTML(d.location)}</span>
      </div>
      <section class="hero2">
        <h1>${escapeHTML(d.name)}</h1>
        <p>${escapeHTML(d.description)}</p>
        <a class="cta" href="#">${escapeHTML(contact)}</a>
      </section>
      <section>
        <p class="eyebrow">${escapeHTML(d.type).toUpperCase()}</p>
        <h2>What we offer</h2>
        <div class="service-grid">${serviceHTML}</div>
      </section>
      <section>
        <h2>Visit us</h2>
        <p class="muted">${escapeHTML(d.location || "Your location")} · ${escapeHTML(d.hours || "Opening hours to be added")}</p>
      </section>
      <div class="footer">© ${new Date().getFullYear()} ${escapeHTML(d.name)} · Built with SiteAI</div>
    </div>`;
}

function escapeHTML(str){
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
